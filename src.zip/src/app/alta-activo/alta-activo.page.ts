import { Component } from '@angular/core';
import { Platform, ToastController } from '@ionic/angular';
import { BluetoothSerial } from '@awesome-cordova-plugins/bluetooth-serial/ngx';
import { AndroidPermissions } from '@awesome-cordova-plugins/android-permissions/ngx';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Geolocation } from '@capacitor/geolocation';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Router } from '@angular/router';

@Component({
  selector: 'app-alta-activo',
  templateUrl: './alta-activo.page.html',
  styleUrls: ['./alta-activo.page.scss'],
})
export class AltaActivoPage {

  activoId = '';
  nombreActivo = '';
  ubicacion = '';
  compania = '';

  selectedFile: File | null = null;
  previewImage: string | null = null;

  constructor(
    private platform: Platform,
    private bluetoothSerial: BluetoothSerial,
    private androidPermissions: AndroidPermissions,
    private toastController: ToastController,
    private http: HttpClient,
    private router: Router
  ) {}

  // ================= FOTO =================
  async tomarFoto() {
    try {
      const image = await Camera.getPhoto({
        quality: 70,
        allowEditing: false,
        resultType: CameraResultType.DataUrl,
        source: CameraSource.Camera
      });

      if (!image?.dataUrl) return;

      this.previewImage = image.dataUrl;
      this.selectedFile = this.base64ToFile(
        image.dataUrl,
        `foto_${Date.now()}.jpg`
      );

    } catch (err) {
      this.showToast('Error cámara ❌', 'danger');
    }
  }

  // ================= LOGOUT (YA RESTAURADO) =================
 

  // ================= GUARDAR =================
async guardarActivoYImprimir() {

  try {

    const token = localStorage.getItem('token');

    if (!token) {
      this.router.navigateByUrl('/login', { replaceUrl: true });
      return;
    }

    const formData = new FormData();

    formData.append('nombre', this.nombreActivo);
    formData.append('ubicacion', this.ubicacion || '');
    formData.append('compania', this.compania || '');
    formData.append('fecha', new Date().toISOString().split('T')[0]);

    const gps = await this.obtenerUbicacion();

    formData.append('latitud', gps?.lat ? String(gps.lat) : '');
    formData.append('longitud', gps?.lng ? String(gps.lng) : '');

    formData.append('fotografia', this.selectedFile!, this.selectedFile!.name);

    const req = this.http.post(
      'http://192.168.68.149/api_activos_v2/public/activos',
      formData,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json'
        }
      }
    );

    req.subscribe({
      next: async (resp: any) => {

        console.log('OK:', resp);

        this.activoId = resp?.id || Date.now().toString();

        await this.imprimirTicket();

        this.limpiarFormulario();

      },
      error: (err) => {
        console.error('ERROR:', err);
      }
    });

  } catch (e) {
    console.error('CATCH:', e);
  }
}
  // ================= GPS =================
  async obtenerUbicacion() {
    try {
      const pos = await Geolocation.getCurrentPosition();
      return {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude
      };
    } catch {
      return null;
    }
  }

  // ================= LIMPIAR =================
  limpiarFormulario() {
    this.nombreActivo = '';
    this.ubicacion = '';
    this.compania = '';
    this.previewImage = null;
    this.selectedFile = null;
  }

  // ================= IMPRIMIR =================
  private async imprimirTicket() {

    if (!this.platform.is('cordova')) {
      this.showToast('Solo en dispositivo real', 'warning');
      return;
    }

    try {

      const devices = await this.bluetoothSerial.list();

      if (!devices?.length) {
        this.showToast('No hay impresora', 'danger');
        return;
      }

      const impresora = devices[0];
      const deviceId = impresora.id || impresora.address;

      await new Promise<void>((resolve, reject) => {
        const sub = this.bluetoothSerial.connect(deviceId).subscribe({
          next: () => {
            sub.unsubscribe();
            resolve();
          },
          error: err => reject(err)
        });
      });

      const ESC = 0x1B;
      const GS = 0x1D;
      const encoder = new TextEncoder();

      const id = `AF-${this.activoId}`;

      const cmds: number[] = [];

      cmds.push(ESC, 0x40);
      cmds.push(ESC, 0x61, 0x01);

      const barcode = encoder.encode(id);
      const len = barcode.length + 3;

      cmds.push(GS, 0x28, 0x6B, len & 0xFF, (len >> 8) & 0xFF, 0x31, 0x50, 0x30, ...barcode);

      cmds.push(0x0A);

      const text =
        `ID: ${id}\n` +
        `Nombre: ${this.nombreActivo}\n` +
        `Ubicación: ${this.ubicacion}\n` +
        `Compañía: ${this.compania}\n`;

      cmds.push(...encoder.encode(text));

      cmds.push(GS, 0x56, 0x00);

      await this.bluetoothSerial.write(new Uint8Array(cmds).buffer);

      try { this.bluetoothSerial.disconnect(); } catch {}

      this.showToast('Ticket impreso ✅', 'success');

    } catch (err) {
      console.error(err);
      this.showToast('Error impresión ❌', 'danger');
    }
  }

  // ================= UTIL =================
  private base64ToFile(dataUrl: string, filename: string): File {

    const arr = dataUrl.split(',');
    const mime = arr[0].match(/:(.*?);/)?.[1] || 'image/jpeg';
    const bstr = atob(arr[1]);

    const u8arr = new Uint8Array(bstr.length);

    for (let i = 0; i < bstr.length; i++) {
      u8arr[i] = bstr.charCodeAt(i);
    }

    return new File([u8arr], filename, { type: mime });
  }

  // ================= TOAST =================
  private async showToast(msg: string, color: string) {
    const toast = await this.toastController.create({
      message: msg,
      duration: 2500,
      color
    });
    toast.present();
  }
}